# Li-Fi-Project-using-Arduino
This github includes the complete code, circuit and APK file of the app used in this Project.

In order to know more please refer to this video: https://youtu.be/o5ASrZSex50
